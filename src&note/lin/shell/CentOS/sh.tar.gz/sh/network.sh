#!/bin/bash - 
#===============================================================================
#
#          FILE: network.sh
# 
#         USAGE: ./network.sh 
# 
#   DESCRIPTION: 
# 
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: YOUR NAME (), 
#  ORGANIZATION: 
#       CREATED: 10/19/2016 00:42
#      REVISION:  ---
#===============================================================================

#set -o nounset                              # Treat unset variables as an error
ping -c 2 www.baidu.com >&/dev/null
if [ $? != 0 ];then
   sudo wpa_supplicant -iwlp3s0 -c /etc/wpa_supplicant/wpa_supplicant.conf -B&&sudo dhcpcd wlp3s0
fi

#
