#!/bin/bash
others="/media"
#[[ -z $1 ]] || [[ -z $2 ]] && exit
if [ ! -d ${others}/$1 ] ; then
 sudo mkdir -pv ${others}/$1
fi

if [ ! -d ${others}/$2 ] ; then
 sudo mkdir -pv ${others}/$2
fi

a=`ls ${others}/$1 -a | wc -l `
if [ -e /dev/disk/by-label/Others ] ; then 
  if [[ -d ${others}/$1 &&  $a -eq 2 ]] ; then
    sudo mount -t ntfs /dev/disk/by-label/Others  ${others}/$1
  fi
fi
if [ -e /dev/disk/by-label/Application ] ; then
 if [ -d $others/$2 ] && [ `ls ${others}/$2 -a|wc -l` -eq 2 ] ;then
 sudo mount -t ntfs /dev/disk/by-label/Application ${others}/$2
 fi
fi
unset a others
#
