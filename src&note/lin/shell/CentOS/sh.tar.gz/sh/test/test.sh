#!/bin/bash - 
#===============================================================================
#
#          FILE: tmp.sh
# 
#         USAGE: ./tmp.sh 
# 
#   DESCRIPTION: 
# 
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: YOUR NAME (), 
#  ORGANIZATION: 
#       CREATED: 2016年12月07日 19:11
#      REVISION:  ---
#===============================================================================

#set -o nounset                              # Treat unset variables as an error
ls -al

