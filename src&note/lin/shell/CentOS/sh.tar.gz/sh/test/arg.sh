#!/bin/bash - 
#===============================================================================
#
#          FILE: arg.sh
# 
#         USAGE: ./arg.sh 
# 
#   DESCRIPTION: 
# 
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: YOUR NAME (), 
#  ORGANIZATION: 
#       CREATED: 01/08/2017 23:23
#      REVISION:  ---
#===============================================================================
echo '$0='$0 '$1='$1 '$2='$2 
function test_arg()
{
	echo 'in function...'
	echo '$0='$0 '$1='$1 '$2='$2 
}
test_arg
unset -f test_arg
